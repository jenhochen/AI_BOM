@echo off
REM BOM Matcher v0.07 - C 案（Streamlit 網頁版）
REM 工作目錄固定為本 bat 所在目錄
cd /d "%~dp0"
title BOM Matcher v0.07 - Streamlit
echo.
echo   BOM Matcher v0.07  -  C 案 Streamlit
echo   目錄: %~dp0
echo   瀏覽器未自動開啟時請手動開 http://localhost:8601
echo.
python -m streamlit run "bom_matcher_C_0.07.py" --server.port 8601 --server.headless false
pause

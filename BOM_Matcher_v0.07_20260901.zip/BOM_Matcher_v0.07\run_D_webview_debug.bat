@echo off
REM BOM Matcher v0.07 - D 案（除錯用：保留主控台，關閉後可看錯誤訊息）
REM 實機測試出問題時用這支，正常使用請用 run_D_webview.bat
cd /d "%~dp0"
title BOM Matcher v0.07 - pywebview (debug)
set PYWEBVIEW_LOG=debug
python "bom_matcher_D_0.07.py"
echo.
echo （視窗已關閉。若上方有錯誤訊息請截圖回報）
pause

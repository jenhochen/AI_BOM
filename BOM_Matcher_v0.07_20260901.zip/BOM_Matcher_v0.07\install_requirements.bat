@echo off
REM BOM Matcher v0.07 - 安裝依賴套件
cd /d "%~dp0"
title BOM Matcher v0.07 - 安裝依賴套件
echo.
echo ================================================
echo   BOM Matcher v0.07  安裝依賴套件
echo   目錄: %~dp0
echo ================================================
echo.

python --version
if errorlevel 1 (
  echo.
  echo [錯誤] 找不到 python。請先安裝 Python 3.10 以上版本，
  echo        安裝時務必勾選 "Add python.exe to PATH"。
  echo        下載: https://www.python.org/downloads/
  echo.
  pause
  exit /b 1
)

echo.
echo 開始安裝...
echo.
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo.
echo ================================================
echo   安裝完成，檢查結果：
echo ================================================
python -c "import pandas,openpyxl,PIL;print('  [OK] 核心      pandas',pandas.__version__,'/ openpyxl',openpyxl.__version__)"
python -c "import streamlit;print('  [OK] C 案      streamlit',streamlit.__version__)" 2>nul || echo   [X]  C 案      streamlit 未安裝
python -c "import webview;print('  [OK] D 案      pywebview',webview.__version__)" 2>nul || echo   [X]  D 案      pywebview 未安裝
echo.
echo 接著可以執行：
echo   run_CLI.bat            先用 CLI 確認核心功能正常
echo   run_C_streamlit.bat    C 案（瀏覽器）
echo   run_D_webview.bat      D 案（原生視窗）
echo.
pause

@echo off
REM BOM Matcher v0.07 - D 案（pywebview 原生視窗版）
cd /d "%~dp0"
title BOM Matcher v0.07 - pywebview
start "" pythonw "bom_matcher_D_0.07.py"

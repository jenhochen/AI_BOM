@echo off
REM BOM Matcher v0.07 - CLI 全自動（不需要 streamlit / pywebview）
cd /d "%~dp0"
title BOM Matcher v0.07 - CLI
echo.
python "bom_core_0.07.py" %*
echo.
pause

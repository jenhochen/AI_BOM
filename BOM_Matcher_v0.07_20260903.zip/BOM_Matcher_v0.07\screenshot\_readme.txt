﻿PCB images (jpg/png) can go here, or in the program folder. The sample pcb.jpg is in the program folder.
